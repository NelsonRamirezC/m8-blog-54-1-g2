--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE m8_blog_54_1_g2;
--
-- Name: m8_blog_54_1_g2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE m8_blog_54_1_g2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Spain.1252';


ALTER DATABASE m8_blog_54_1_g2 OWNER TO postgres;

\unrestrict (null)
\connect m8_blog_54_1_g2
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Comentarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Comentarios" (
    id integer NOT NULL,
    publicacion_id integer NOT NULL,
    usuario_id integer NOT NULL,
    contenido text NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public."Comentarios" OWNER TO postgres;

--
-- Name: Comentarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Comentarios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Comentarios_id_seq" OWNER TO postgres;

--
-- Name: Comentarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Comentarios_id_seq" OWNED BY public."Comentarios".id;


--
-- Name: Publicaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Publicaciones" (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    contenido text NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public."Publicaciones" OWNER TO postgres;

--
-- Name: Publicaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Publicaciones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Publicaciones_id_seq" OWNER TO postgres;

--
-- Name: Publicaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Publicaciones_id_seq" OWNED BY public."Publicaciones".id;


--
-- Name: Usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Usuarios" (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    imagen_avatar bytea,
    mimetype character varying(50)
);


ALTER TABLE public."Usuarios" OWNER TO postgres;

--
-- Name: Usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Usuarios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Usuarios_id_seq" OWNER TO postgres;

--
-- Name: Usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Usuarios_id_seq" OWNED BY public."Usuarios".id;


--
-- Name: Comentarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comentarios" ALTER COLUMN id SET DEFAULT nextval('public."Comentarios_id_seq"'::regclass);


--
-- Name: Publicaciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Publicaciones" ALTER COLUMN id SET DEFAULT nextval('public."Publicaciones_id_seq"'::regclass);


--
-- Name: Usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Usuarios" ALTER COLUMN id SET DEFAULT nextval('public."Usuarios_id_seq"'::regclass);


--
-- Data for Name: Comentarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Comentarios" (id, publicacion_id, usuario_id, contenido, fecha_creacion, fecha_actualizacion) FROM stdin;
\.
COPY public."Comentarios" (id, publicacion_id, usuario_id, contenido, fecha_creacion, fecha_actualizacion) FROM '$$PATH$$/4949.dat';

--
-- Data for Name: Publicaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Publicaciones" (id, usuario_id, titulo, contenido, fecha_creacion, fecha_actualizacion) FROM stdin;
\.
COPY public."Publicaciones" (id, usuario_id, titulo, contenido, fecha_creacion, fecha_actualizacion) FROM '$$PATH$$/4947.dat';

--
-- Data for Name: Usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Usuarios" (id, nombre, email, password, admin, status, fecha_creacion, fecha_actualizacion, imagen_avatar, mimetype) FROM stdin;
\.
COPY public."Usuarios" (id, nombre, email, password, admin, status, fecha_creacion, fecha_actualizacion, imagen_avatar, mimetype) FROM '$$PATH$$/4945.dat';

--
-- Name: Comentarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Comentarios_id_seq"', 1, true);


--
-- Name: Publicaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Publicaciones_id_seq"', 2, true);


--
-- Name: Usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Usuarios_id_seq"', 5, true);


--
-- Name: Comentarios Comentarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comentarios"
    ADD CONSTRAINT "Comentarios_pkey" PRIMARY KEY (id);


--
-- Name: Publicaciones Publicaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Publicaciones"
    ADD CONSTRAINT "Publicaciones_pkey" PRIMARY KEY (id);


--
-- Name: Usuarios Usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Usuarios"
    ADD CONSTRAINT "Usuarios_email_key" UNIQUE (email);


--
-- Name: Usuarios Usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Usuarios"
    ADD CONSTRAINT "Usuarios_pkey" PRIMARY KEY (id);


--
-- Name: Comentarios Comentarios_publicacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comentarios"
    ADD CONSTRAINT "Comentarios_publicacion_id_fkey" FOREIGN KEY (publicacion_id) REFERENCES public."Publicaciones"(id) ON DELETE CASCADE;


--
-- Name: Comentarios Comentarios_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comentarios"
    ADD CONSTRAINT "Comentarios_usuario_id_fkey" FOREIGN KEY (usuario_id) REFERENCES public."Usuarios"(id) ON DELETE CASCADE;


--
-- Name: Publicaciones Publicaciones_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Publicaciones"
    ADD CONSTRAINT "Publicaciones_usuario_id_fkey" FOREIGN KEY (usuario_id) REFERENCES public."Usuarios"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

